# xbmc-pl-tv
Polish TV addons for KODI (XBMC). Includes TVP and TVN VOD services. It's based on smuto project.
Download repo from https://github.com/pkontek/xbmc-pl-tv/tree/master/repo/repository.xbmc-pl-tv and install add-on from zip file.

Dodatki polskich serwisów TV do KODI (XBMC).Zawiera serwisy VOD TVP i TVN. Bazuje na projekcie smuto.
Pobierz najnowszą wersję repozytorium wtyczek z https://github.com/pkontek/xbmc-pl-tv/tree/master/repo/repository.xbmc-pl-tv i w XBMC zainstaluj wtyczki z pliku ZIP.
