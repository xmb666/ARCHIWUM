# plugin.audio.open_FM
KODI's plugin for OPEN.FM
Plugin pozwala odtwarzać internetowe radio open.fm na urządzeniach z systemem KODI.
