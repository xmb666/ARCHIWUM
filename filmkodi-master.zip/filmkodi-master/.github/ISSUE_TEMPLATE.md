## Please follow the guide below 
- Put an "x" into all boxes [ ] relevant to your *issue*
- Use *Preview* tab to see how your issue will actually look like
---
## Kodi & Addon 
- Kodi verison: _____
- [ ] Filmy online - Mrknow
- [ ] MrknowTV
- [ ] Specto
- [ ] FanFILM
- Version / Wersja: _____
---
## Descryption / Opis
Put here every imported thing such logs, how to reproduce etc. <br/>
Wstaw tutaj każdą ważna rzecz, taką jak logi, jak wywołać błąd itp.

## Donation / Darowizna
This addons are free, but you can always thank the author for ... / Te wtyczki są darmowe, ale zawsze możesz podziękować autorowi za jej stworzenie...

[![paypal](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=HEV6TJY83S3Q4&lc=PL&item_name=Donation-Darowizna&currency_code=PLN&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted)
