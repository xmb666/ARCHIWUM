import pydevd

pydevd.settrace('localhost', port='20202')

