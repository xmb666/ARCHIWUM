# Mrknow repository KODI addons / Repozytorium wtyczek do Kodi 


## Website / Strona - http://filmkodi.com ##

![Filmy online - mrknow](http://filmkodi.com/wp-content/uploads/2015/08/mrknow.png)


## Donation / Darowizna
This addons are free, but you can always thank the author for it ... 

Te wtyczki są darmowe, ale zawsze możesz podziękować autorowi za jej stworzenie...

[![paypal](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=HEV6TJY83S3Q4&lc=PL&item_name=Donation-Darowizna&currency_code=PLN&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted)
