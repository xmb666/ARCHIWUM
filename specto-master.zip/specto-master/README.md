# specto

# Mrknow repository KODI addons  


## Website http://filmkodi.com/en/specto-1080p-kodi-add/ ##

![Specto](http://filmkodi.com/wp-content/uploads/2015/08/icon-2-e1466245667753.png)


## Donation / Darowizna
This addons are free, but you can always thank the author for it 

[![paypal](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=HEV6TJY83S3Q4&lc=PL&item_name=Donation-Darowizna&currency_code=PLN&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted)
