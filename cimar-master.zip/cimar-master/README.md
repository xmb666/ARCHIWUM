Repozytorium RAMIC MOD (kopia oryginalnego repo z ktorej staramy sie wyciac zlosliwy kod)
1. nie mamy 100% pewnosci czy wyciety jest caly zlosliwy kod
2. nie mamy pewnosci czy autor ramic  nie pozostawil back dorow umozliwiajacych zdalne uruchamianie zlosliwego kodu
3.  Jeśli nie posiadasz uprawnień do zawartości udostępnianej przez wtyczki to nie masz powodu by je instalować
4.AUTOR REPOZYTORIUM NIE PONOSI ŻADNEJ ODPOWIEDZIALNOŚCI ZA SZKODY WYNIKŁE Z UŻYTKOWANIA ELEMANTÓW W NIM ZAWARTYCH (INSTALUJESZ NA WŁĄSNĄ ODPOWIEDZIALNOŚĆ)
5.epozytorium nie zwiera żadnego kontenu chronionego prawami autorskimi. (patrz na info każdej wtyczki/repo przed zainstalowaniem o ile autor je umieścił).

DO INSTALACJI JEDYNIE NA CZYSTE KODI/ PO FRESH START, NIE WOLNO INSTALOWAC ORYGINALNEGO REPO RAMICA WRAZ Z TYM REPO
( DORADZAM INSTALOWAC TYLKO NA BOXACH)

REPOZYTORIUM NIE BEDZIE POSIADAC WYPROWADZENIA DO INSTALACJI PRZEZ ADRES Z FILE MANAGERA, JEST CHODZACE ALE KAZDY BEDZIE MUSIAL WEJSC TU, BY PRZED ZASSANIEM PRZECZYTAC CZYM GROZI JEGO INSTALACJA ramic/repository.ramic/repository.ramic-1.3.9.zip <= JESLI CHCECIE

LEPSZY ZAMIENNIK RAMICA:
repo Incursion - fork exodus/covenant zastapi 20+ filmowo serialowych wtyczek
repo Phantom - CDA plugin
repo CHERRY TV - kreskowkazone, animezone, ekstraklasa, sport365, MontyPyton, kamerki, strefadb,tvp.pl VOD
